﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace prKol_ind3_Borisov
{
    class Vector3D
    {
        private ArrayList start;
        private ArrayList end;
        public Vector3D(double x1, double y1, double z1, double x2, double y2, double z2)
        {
            start = new ArrayList();
            end = new ArrayList();
            start.Add(x1);
            start.Add(y1);
            start.Add(z1);
            end.Add(x2);
            end.Add(y2);
            end.Add(z2);
        }
        public Vector3D(double x, double y, double z) : this(0, 0, 0, x, y, z) { }
        public ArrayList GetCoordinats()
        {
            ArrayList coord = new ArrayList();
            coord.Add((double)end[0] - (double)start[0]);
            coord.Add((double)end[1] - (double)start[1]);
            coord.Add((double)end[2] - (double)start[2]);
            return coord;
        }
        public Vector3D Sum(Vector3D otherVector)
        {
            ArrayList result = new ArrayList();
            ArrayList coord = this.GetCoordinats();
            ArrayList OtherCoord = otherVector.GetCoordinats();
            for (int i = 0; i < 3; i++)
            {
                double sum = (double)coord[i] + (double)OtherCoord[i];
                result.Add(sum);
            }
            return new Vector3D(0, 0, 0, (double)result[0], (double)result[1], (double)result[2]);
        }
        public Vector3D Subtraction(Vector3D orherVector2)
        {
            ArrayList coord2 = this.GetCoordinats();
            ArrayList otherCoord2 = orherVector2.GetCoordinats();
            return new Vector3D((double)coord2[0] - (double)otherCoord2[0], (double)coord2[1] - (double)otherCoord2[1], (double)coord2[2] - (double)otherCoord2[2]);
        }
        public double SkalyarProiz(Vector3D otherVector3)
        {
            ArrayList coord3 = this.GetCoordinats();
            ArrayList otherCoord3 = otherVector3.GetCoordinats();
            return (double)coord3[0] * (double)otherCoord3[0]
                 + (double)coord3[1] * (double)otherCoord3[1]
                 + (double)coord3[2] * (double)otherCoord3[2];
        }
        public double Length()
        {
            ArrayList coords = GetCoordinats();
            double x = (double)coords[0];
            double y = (double)coords[1];
            double z = (double)coords[2];
            return Math.Sqrt(x * x + y * y + z * z);
        }
        public double Cos(Vector3D otherVector)
        {
            return SkalyarProiz(otherVector) / (Length() * otherVector.Length());
        }
        public override string ToString()
        {
            ArrayList coords = GetCoordinats();
            return $"{coords[0]}, {coords[1]}, {coords[2]}";
        }
    }
}
