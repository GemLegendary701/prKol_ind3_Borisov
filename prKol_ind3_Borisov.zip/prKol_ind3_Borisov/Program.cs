﻿using System;

namespace prKol_ind3_Borisov
{
    class Program
    {
        static void Main(string[] args)
        {
            Vector3D vector1 = new Vector3D(1, 2, 3);
            Vector3D vector2 = new Vector3D(4, 5, 6);
            Vector3D sum = vector1.Sum(vector2);
            Console.WriteLine($"Сумма векторов: ({sum})");
            Vector3D subtraction = vector1.Subtraction(vector2);
            Console.WriteLine($"Разность векторов: ({subtraction})");
            double Sproizv = vector1.SkalyarProiz(vector2);
            Console.WriteLine($"Скалярное произведение векторов: {Sproizv}");
            double length1 = vector1.Length();
            double length2 = vector2.Length();
            Console.WriteLine($"Длинна 1 вектора: {length1:F2}");
            Console.WriteLine($"Длинна 2 вектора: {length2:F2}");
            double cos = vector1.Cos(vector2);
            Console.WriteLine($"Косинус угла между векторами: {cos:F2}");

        }
    }
}
