﻿
namespace prKol_ind3_Borisov_zd4
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            CreateArray = new System.Windows.Forms.Button();
            SetValue = new System.Windows.Forms.Button();
            GetValue = new System.Windows.Forms.Button();
            Add = new System.Windows.Forms.Button();
            Multiplication = new System.Windows.Forms.Button();
            Substract = new System.Windows.Forms.Button();
            display = new System.Windows.Forms.Button();
            result = new System.Windows.Forms.Label();
            textBox1Size = new System.Windows.Forms.TextBox();
            textBox2Index = new System.Windows.Forms.TextBox();
            textBox3Value = new System.Windows.Forms.TextBox();
            textBox4Factor = new System.Windows.Forms.TextBox();
            textBoxArrNumber = new System.Windows.Forms.TextBox();
            label1 = new System.Windows.Forms.Label();
            label2 = new System.Windows.Forms.Label();
            label3 = new System.Windows.Forms.Label();
            label4 = new System.Windows.Forms.Label();
            label5 = new System.Windows.Forms.Label();
            label6 = new System.Windows.Forms.Label();
            SuspendLayout();
            // 
            // CreateArray
            // 
            CreateArray.Location = new System.Drawing.Point(35, 30);
            CreateArray.Name = "CreateArray";
            CreateArray.Size = new System.Drawing.Size(114, 44);
            CreateArray.TabIndex = 0;
            CreateArray.Text = "Создать массивы";
            CreateArray.UseVisualStyleBackColor = true;
            CreateArray.Click += CreateArray_Click;
            // 
            // SetValue
            // 
            SetValue.Location = new System.Drawing.Point(35, 93);
            SetValue.Name = "SetValue";
            SetValue.Size = new System.Drawing.Size(114, 44);
            SetValue.TabIndex = 1;
            SetValue.Text = "Установить значение";
            SetValue.UseVisualStyleBackColor = true;
            SetValue.Click += SetValue_Click;
            // 
            // GetValue
            // 
            GetValue.Location = new System.Drawing.Point(179, 93);
            GetValue.Name = "GetValue";
            GetValue.Size = new System.Drawing.Size(114, 44);
            GetValue.TabIndex = 2;
            GetValue.Text = "Получить значение";
            GetValue.UseVisualStyleBackColor = true;
            GetValue.Click += GetValue_Click;
            // 
            // Add
            // 
            Add.Location = new System.Drawing.Point(35, 157);
            Add.Name = "Add";
            Add.Size = new System.Drawing.Size(114, 44);
            Add.TabIndex = 3;
            Add.Text = "Сложить массивы";
            Add.UseVisualStyleBackColor = true;
            Add.Click += Add_Click;
            // 
            // Multiplication
            // 
            Multiplication.Location = new System.Drawing.Point(179, 157);
            Multiplication.Name = "Multiplication";
            Multiplication.Size = new System.Drawing.Size(114, 44);
            Multiplication.TabIndex = 4;
            Multiplication.Text = "Умножить массив на число";
            Multiplication.UseVisualStyleBackColor = true;
            Multiplication.Click += Multiplication_Click;
            // 
            // Substract
            // 
            Substract.Location = new System.Drawing.Point(35, 218);
            Substract.Name = "Substract";
            Substract.Size = new System.Drawing.Size(114, 44);
            Substract.TabIndex = 5;
            Substract.Text = "Вычесть массивы";
            Substract.UseVisualStyleBackColor = true;
            Substract.Click += Substract_Click;
            // 
            // display
            // 
            display.Location = new System.Drawing.Point(179, 30);
            display.Name = "display";
            display.Size = new System.Drawing.Size(114, 44);
            display.TabIndex = 6;
            display.Text = "Вывести массивы";
            display.UseVisualStyleBackColor = true;
            display.Click += display_Click;
            // 
            // result
            // 
            result.AutoSize = true;
            result.Location = new System.Drawing.Point(518, 193);
            result.Name = "result";
            result.Size = new System.Drawing.Size(123, 15);
            result.TabIndex = 7;
            result.Text = "Результат операций: ";
            // 
            // textBox1Size
            // 
            textBox1Size.Location = new System.Drawing.Point(337, 51);
            textBox1Size.Name = "textBox1Size";
            textBox1Size.Size = new System.Drawing.Size(121, 23);
            textBox1Size.TabIndex = 9;
            // 
            // textBox2Index
            // 
            textBox2Index.Location = new System.Drawing.Point(337, 114);
            textBox2Index.Name = "textBox2Index";
            textBox2Index.Size = new System.Drawing.Size(121, 23);
            textBox2Index.TabIndex = 10;
            // 
            // textBox3Value
            // 
            textBox3Value.Location = new System.Drawing.Point(537, 111);
            textBox3Value.Name = "textBox3Value";
            textBox3Value.Size = new System.Drawing.Size(121, 23);
            textBox3Value.TabIndex = 11;
            // 
            // textBox4Factor
            // 
            textBox4Factor.Location = new System.Drawing.Point(337, 185);
            textBox4Factor.Name = "textBox4Factor";
            textBox4Factor.Size = new System.Drawing.Size(121, 23);
            textBox4Factor.TabIndex = 12;
            // 
            // textBoxArrNumber
            // 
            textBoxArrNumber.Location = new System.Drawing.Point(537, 53);
            textBoxArrNumber.Name = "textBoxArrNumber";
            textBoxArrNumber.Size = new System.Drawing.Size(121, 23);
            textBoxArrNumber.TabIndex = 13;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new System.Drawing.Point(339, 22);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(173, 15);
            label1.TabIndex = 14;
            label1.Text = "Размер массивов ( больше 0 )";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new System.Drawing.Point(537, 22);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(104, 15);
            label2.TabIndex = 15;
            label2.Text = "Выберите массив";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new System.Drawing.Point(337, 93);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(151, 15);
            label3.TabIndex = 16;
            label3.Text = "Индекс элемента массива";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new System.Drawing.Point(537, 93);
            label4.Name = "label4";
            label4.Size = new System.Drawing.Size(115, 15);
            label4.TabIndex = 17;
            label4.Text = "Значение элемента";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new System.Drawing.Point(337, 157);
            label5.Name = "label5";
            label5.Size = new System.Drawing.Size(0, 15);
            label5.TabIndex = 18;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new System.Drawing.Point(337, 157);
            label6.Name = "label6";
            label6.Size = new System.Drawing.Size(159, 15);
            label6.TabIndex = 19;
            label6.Text = "множитель для умножения";
            // 
            // Form1
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            ClientSize = new System.Drawing.Size(800, 450);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(textBoxArrNumber);
            Controls.Add(textBox4Factor);
            Controls.Add(textBox3Value);
            Controls.Add(textBox2Index);
            Controls.Add(textBox1Size);
            Controls.Add(result);
            Controls.Add(display);
            Controls.Add(Substract);
            Controls.Add(Multiplication);
            Controls.Add(Add);
            Controls.Add(GetValue);
            Controls.Add(SetValue);
            Controls.Add(CreateArray);
            Name = "Form1";
            Text = "zd4";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Button CreateArray;
        private System.Windows.Forms.Button SetValue;
        private System.Windows.Forms.Button GetValue;
        private System.Windows.Forms.Button Add;
        private System.Windows.Forms.Button Multiplication;
        private System.Windows.Forms.Button Substract;
        private System.Windows.Forms.Button display;
        private System.Windows.Forms.Label result;
        private System.Windows.Forms.TextBox textBox1Size;
        private System.Windows.Forms.TextBox textBox2Index;
        private System.Windows.Forms.TextBox textBox3Value;
        private System.Windows.Forms.TextBox textBox4Factor;
        private System.Windows.Forms.TextBox textBoxArrNumber;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
    }
}

