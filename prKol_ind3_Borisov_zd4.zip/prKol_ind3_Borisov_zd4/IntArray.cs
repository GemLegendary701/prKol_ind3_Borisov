﻿using System;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prKol_ind3_Borisov_zd4
{
    public class IntArray
    {
        private ArrayList array;
        private int size;

        public IntArray(int size)
        {
            if (size <= 0)
                throw new ArgumentException("Размер массива должен быть положительным числом");
            this.size = size;
            array = new ArrayList(size);
            for (int i = 0; i < size; i++)
            {
                array.Add(0);
            }
        }
        private void CheckIndex(int index)
        {
            if (index < 0 || index >= size)
            {
                throw new IndexOutOfRangeException($"Индекс выходит за границы массива [0, {size - 1}]");
            }
        }
        public int Get(int index)
        {
            CheckIndex(index);
            return (int)array[index];
        }
        public void Set(int index, int value)
        {
            CheckIndex(index);
            array[index] = value;
        }
        public IntArray Add(IntArray other)
        {
            if (other == null || other.size != this.size)
                throw new ArgumentException("Массивы должны быть одинакового размера");
            IntArray result = new IntArray(size);
            for (int i = 0; i < size; i++)
            {
                result.Set(i, this.Get(i) + other.Get(i));
            }
            return result;
        }
        public IntArray Subtract(IntArray other)
        {
            if (other == null || other.size != this.size)
            {
                throw new ArgumentException("Массивы должны быть одного размера");
            }
            IntArray result = new IntArray(size);
            for (int i = 0; i < size; i++)
            {
                result.Set(i, this.Get(i) - other.Get(i));
            }
            return result;
        }
        public IntArray Multiply(int multiplier)
        {
            IntArray result = new IntArray(size);
            for (int i = 0; i < size; i++)
            {
                result.Set(i, this.Get(i) * multiplier);
            }
            return result;
        }
        public override string ToString()
        {
            var elements = new string[size];
            for (int i = 0; i < size; i++)
            {
                elements[i] = ((int)array[i]).ToString();
            }
            return string.Join(", ", elements);
        }
    }
}