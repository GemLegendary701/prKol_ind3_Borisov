﻿using System;
using System.Windows.Forms;

namespace prKol_ind3_Borisov_zd4
{
    public partial class Form1 : Form
    {
        public IntArray array1, array2, resArray;

        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }
        private void CreateArray_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(textBox1Size.Text, out int size) || size <= 0)
            {
                MessageBox.Show("Введите корректный размер массива (целое число > 0)");
            }
            array1 = new IntArray(size);
            array2 = new IntArray(size);
            MessageBox.Show($"Два массива размером {size} созданы");
        }
        private void display_Click(object sender, EventArgs e)
        {
            try
            {
                string output = $"Массив 1: {(array1?.ToString() ?? "не создан")}\n";
                output += $"Массив 2: {(array2?.ToString() ?? "не создан")}\n";
                output += $"Результат: {(resArray?.ToString() ?? "нет операций")}";
                result.Text = output;
            }
            catch (Exception)
            {
                MessageBox.Show($"Ошибка");
            }
        }
        private void SetValue_Click(object sender, EventArgs e)
        {
            try
            {
                if (!int.TryParse(textBoxArrNumber.Text, out int arrayNum) ||
                    !int.TryParse(textBox2Index.Text, out int index) ||
                    !int.TryParse(textBox3Value.Text, out int value))
                {
                    MessageBox.Show("Проверьте корректность ввода данных");
                    return;
                }
                IntArray targetArray = arrayNum == 1 ? array1 : array2;
                if (targetArray == null)
                {
                    MessageBox.Show("Сначала создайте массивы");
                }

                targetArray.Set(index, value);
                MessageBox.Show($"Значение {value} занесено в массив {arrayNum} по индексу {index}");
            }
            catch (Exception)
            {
                MessageBox.Show($"Ошибка");
            }
        }
        private void GetValue_Click(object sender, EventArgs e)
        {
            try
            {
                if (!int.TryParse(textBoxArrNumber.Text, out int arrayNum) ||
                    !int.TryParse(textBox2Index.Text, out int index))
                {
                    MessageBox.Show("Проверьте корректность ввода индекса");
                    return;
                }
                IntArray targetArray = arrayNum == 1 ? array1 : array2;
                if (targetArray == null)
                {
                    MessageBox.Show("Сначала создайте массивы");
                }

                int value = targetArray.Get(index);
                result.Text = $"Значение в массиве {arrayNum} по индексу {index}: {value}";
            }
            catch (Exception)
            {
                MessageBox.Show($"Ошибка");
            }
        }
        private void Add_Click(object sender, EventArgs e)
        {
            try
            {
                if (array1 == null || array2 == null)
                {
                    MessageBox.Show("создайте оба массива");
                }
                resArray = array1.Add(array2);
                result.Text = $"Результат сложения:\n{resArray}";
            }
            catch (Exception)
            {
                MessageBox.Show($"Ошибка");
            }
        }
        private void Substract_Click(object sender, EventArgs e)
        {
            try
            {
                if (array1 == null || array2 == null)
                {
                    MessageBox.Show("создайте оба массива");
                }
                resArray = array1.Subtract(array2);
                result.Text = $"Результат вычитания:\n{resArray}";
            }
            catch (Exception)
            {
                MessageBox.Show($"Ошибка");
            }
        }
        private void Multiplication_Click(object sender, EventArgs e)
        {
            try
            {
                if (!int.TryParse(textBoxArrNumber.Text, out int arrayNum) || 
                    !int.TryParse(textBox4Factor.Text, out int multiplier))
                {
                    MessageBox.Show("Некорректный ввод множителя");
                    return;
                }
                IntArray targetArray = arrayNum == 1 ? array1 : array2;
                if (targetArray == null)
                {
                    MessageBox.Show("создайте массивы");
                }
                resArray = targetArray.Multiply(multiplier);
                result.Text = $"Результат умножения массива {arrayNum} на {multiplier}:\n{resArray}";
            }
            catch (Exception)
            {
                MessageBox.Show($"Ошибка");
            }
        }
    }
}